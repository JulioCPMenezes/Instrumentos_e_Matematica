export const familias = {
  cordas: {
    nome: 'Cordas',
    cor: '#d2a540',
    oQueVibra: 'Cordas tensionadas',
    inicio: 'Fricção com arco, dedilhado ou percussão.',
    formula: 'f = (1 / 2L) · √(T / μ)',
    explicacao: 'Menor comprimento e maior tensão elevam a frequência. Maior massa por metro reduz a frequência.',
    variaveis: 'comprimento L, tensão T e densidade linear μ',
    instrumentos: ['violino', 'viola', 'violoncelo', 'contrabaixo']
  },
  madeiras: {
    nome: 'Madeiras',
    cor: '#708d81',
    oQueVibra: 'Coluna de ar',
    inicio: 'Jato de ar, palheta simples ou palheta dupla.',
    formula: 'aberto: fₙ = nv / 2L · fechado: fₙ = (2n−1)v / 4L',
    explicacao: 'Abrir furos encurta aproximadamente o comprimento acústico. Tubos reais exigem correções de forma, diâmetro e extremidades.',
    variaveis: 'comprimento acústico, temperatura, geometria e furos',
    instrumentos: ['piccolo', 'flauta', 'clarinete', 'fagote']
  },
  metais: {
    nome: 'Metais',
    cor: '#b66c36',
    oQueVibra: 'Lábios e coluna de ar',
    inicio: 'Os lábios vibram no bocal e excitam ressonâncias do tubo.',
    formula: 'ΔL = L · (2^(k/12) − 1)',
    explicacao: 'Válvulas e vara aumentam o caminho do ar. Um tubo mais longo favorece frequências menores.',
    variaveis: 'comprimento do tubo, formato interno, bocal e campana',
    instrumentos: ['trompete', 'trompa', 'trombone', 'tuba']
  },
  percussao: {
    nome: 'Percussão e teclas',
    cor: '#7e2f42',
    oQueVibra: 'Membranas, barras, placas ou cordas percutidas',
    inicio: 'Impacto, agitação ou acionamento de teclas.',
    formula: 'membrana: f ∝ (1/r)√(S/σ) · barra: f ∝ 1/L²',
    explicacao: 'Tambores dependem do raio, tensão e massa superficial. Barras dependem fortemente do comprimento, espessura e material.',
    variaveis: 'raio, tensão, densidade, comprimento, rigidez e espessura',
    instrumentos: ['timpano', 'xilofone', 'triangulo', 'celesta']
  }
};
