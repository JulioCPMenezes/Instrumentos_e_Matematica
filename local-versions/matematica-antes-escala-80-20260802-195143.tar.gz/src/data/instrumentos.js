export const instrumentos = {
  violino: {
    nome: 'Violino', familia: 'cordas', imagem: 'violino.webp', demoHz: 659.25,
    faixa: 'aprox. 196–3.100 Hz', tamanho: 'corpo de cerca de 36 cm',
    producao: 'Cordas friccionadas por arco; o corpo de madeira irradia a vibração.',
    matematica: 'Comprimento vibrante, tensão e densidade linear.',
    curiosidade: 'Ao encurtar uma corda com o dedo, o músico aumenta sua frequência.'
  },
  viola: {
    nome: 'Viola', familia: 'cordas', imagem: 'viola.webp', demoHz: 440,
    faixa: 'aprox. 131–1.175 Hz', tamanho: 'corpo geralmente entre 39 e 43 cm',
    producao: 'Cordas friccionadas, com corpo maior que o do violino.',
    matematica: 'Maior comprimento e cordas mais pesadas favorecem sons mais graves.',
    curiosidade: 'Não existe um único tamanho padronizado para todas as violas.'
  },
  violoncelo: {
    nome: 'Violoncelo', familia: 'cordas', imagem: 'violoncelo.webp', demoHz: 220,
    faixa: 'aprox. 65–988 Hz', tamanho: 'corpo de cerca de 76 cm',
    producao: 'Cordas friccionadas; o espigão apoia o instrumento no chão.',
    matematica: 'Escala mais longa e cordas de maior massa por metro.',
    curiosidade: 'Seu 12º semitom em uma corda aparece quando o comprimento vibrante é reduzido à metade.'
  },
  contrabaixo: {
    nome: 'Contrabaixo', familia: 'cordas', imagem: 'contrabaixo.webp', demoHz: 98,
    faixa: 'aprox. 41–392 Hz', tamanho: 'altura total próxima de 1,8 m',
    producao: 'Cordas friccionadas ou dedilhadas com grande caixa de ressonância.',
    matematica: 'Comprimento maior e cordas mais pesadas permitem frequências graves.',
    curiosidade: 'Muitos contrabaixos orquestrais são afinados em quartas.'
  },
  piccolo: {
    nome: 'Flautim', familia: 'madeiras', imagem: 'piccolo.webp', demoHz: 1046.5,
    faixa: 'aprox. 523–4.000 Hz', tamanho: 'cerca de 32 cm',
    producao: 'Jato de ar sobre a embocadura excita a coluna de ar.',
    matematica: 'Coluna de ar curta produz frequências mais altas.',
    curiosidade: 'Soa uma oitava acima da flauta transversal em muitas partituras.'
  },
  flauta: {
    nome: 'Flauta transversal', familia: 'madeiras', imagem: 'flauta.webp', demoHz: 880,
    faixa: 'aprox. 262–2.100 Hz', tamanho: 'cerca de 67 cm',
    producao: 'O jato de ar alterna na borda da embocadura.',
    matematica: 'Os furos alteram o comprimento acústico efetivo.',
    curiosidade: 'Apesar do nome da família, muitas flautas modernas são construídas em metal.'
  },
  clarinete: {
    nome: 'Clarinete', familia: 'madeiras', imagem: 'clarinete.webp', demoHz: 392,
    faixa: 'aprox. 147–1.570 Hz', tamanho: 'aprox. 66 cm',
    producao: 'Uma palheta simples vibra no bocal.',
    matematica: 'A aproximação de tubo fechado ajuda a explicar a presença forte de harmônicos ímpares no registro grave.',
    curiosidade: 'Sua geometria cilíndrica o diferencia de instrumentos cônicos.'
  },
  fagote: {
    nome: 'Fagote', familia: 'madeiras', imagem: 'fagote.webp', demoHz: 146.83,
    faixa: 'aprox. 58–622 Hz', tamanho: 'tubo desenrolado com mais de 2 m',
    producao: 'Palheta dupla acoplada a um tubo longo dobrado.',
    matematica: 'Grande comprimento acústico favorece frequências graves.',
    curiosidade: 'O tubo é dobrado para tornar o instrumento utilizável.'
  },
  trompete: {
    nome: 'Trompete', familia: 'metais', imagem: 'trompete.webp', demoHz: 466.16,
    faixa: 'aprox. 165–1.175 Hz', tamanho: 'tubo de cerca de 1,4 m quando desenrolado',
    producao: 'Lábios vibram no bocal e excitam a coluna de ar.',
    matematica: 'Válvulas acrescentam diferentes comprimentos de tubo.',
    curiosidade: 'A segunda válvula abaixa aproximadamente um semitom.'
  },
  trompa: {
    nome: 'Trompa', familia: 'metais', imagem: 'trompa.webp', demoHz: 349.23,
    faixa: 'aprox. 87–880 Hz', tamanho: 'tubo de vários metros enrolado',
    producao: 'Lábios no bocal, tubo predominantemente cônico e campana ampla.',
    matematica: 'Comprimento, conicidade e posição da mão alteram as ressonâncias.',
    curiosidade: 'O músico pode ajustar o som colocando a mão na campana.'
  },
  trombone: {
    nome: 'Trombone', familia: 'metais', imagem: 'trombone.webp', demoHz: 233.08,
    faixa: 'aprox. 82–700 Hz', tamanho: 'tubo de cerca de 2,7 m',
    producao: 'Vibração dos lábios; a vara muda continuamente o comprimento.',
    matematica: 'A posição da vara representa uma mudança contínua, não apenas passos discretos.',
    curiosidade: 'Permite glissandos naturais pela movimentação da vara.'
  },
  tuba: {
    nome: 'Tuba', familia: 'metais', imagem: 'tuba.webp', demoHz: 65.41,
    faixa: 'aprox. 33–392 Hz', tamanho: 'tubo que pode ultrapassar 5 m',
    producao: 'Coluna de ar longa excitada pelos lábios.',
    matematica: 'O grande comprimento acústico favorece notas graves.',
    curiosidade: 'É o instrumento mais grave da família dos metais na orquestra.'
  },
  timpano: {
    nome: 'Tímpano', familia: 'percussao', imagem: 'timpano.webp', demoHz: 110,
    faixa: 'aprox. 65–294 Hz', tamanho: 'diâmetros diferentes conforme o conjunto',
    producao: 'Membrana esticada sobre um corpo em forma de caldeira.',
    matematica: 'O pedal altera a tensão da membrana e, com ela, a frequência.',
    curiosidade: 'Diferentemente de muitos tambores, pode ser afinado em notas definidas.'
  },
  xilofone: {
    nome: 'Xilofone', familia: 'percussao', imagem: 'xilofone.webp', demoHz: 880,
    faixa: 'aprox. 523–4.186 Hz', tamanho: 'barras de comprimentos graduais',
    producao: 'Barras rígidas vibram por flexão após o impacto da baqueta.',
    matematica: 'Em um modelo uniforme, a frequência varia aproximadamente com 1/L².',
    curiosidade: 'Entalhes na face inferior ajudam a ajustar a fundamental e os parciais.'
  },
  triangulo: {
    nome: 'Triângulo', familia: 'percussao', imagem: 'triangulo.webp', demoHz: 1760,
    faixa: 'espectro amplo e inarmônico', tamanho: 'aprox. 15–30 cm',
    producao: 'Uma barra metálica dobrada vibra após o impacto.',
    matematica: 'Forma, espessura, material e pontos de apoio influenciam seus modos.',
    curiosidade: 'Seu espectro não forma uma série harmônica simples.'
  },
  celesta: {
    nome: 'Celesta', familia: 'percussao', imagem: 'celesta.webp', demoHz: 1046.5,
    faixa: 'aprox. 131–4.186 Hz', tamanho: 'instrumento de teclado',
    producao: 'Teclas acionam martelos que percutem placas metálicas.',
    matematica: 'Comprimento, espessura e rigidez das placas definem frequências.',
    curiosidade: 'Ressonadores ajudam a reforçar o som das placas.'
  }
};
