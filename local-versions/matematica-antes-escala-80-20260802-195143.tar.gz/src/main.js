import {
  applySiteConfig,
  initExplorer,
  initFamilies,
  initIntro,
  initMascotWidget,
  initNavigation,
  initOrchestra,
  initPresentation,
  initTimeline
} from './sections/layout.js';
import { initMathLabs, initComparator } from './sections/labs.js';
import { initBasicWave, initSoundLab } from './sections/sound.js';
import { initHallAcoustics } from './sections/acoustics.js';
import { initExperiment } from './sections/experiment.js';

function safely(name, callback) {
  try {
    const result = callback();
    if (result?.catch) {
      result.catch(error => {
        console.error(`Falha ao iniciar ${name}:`, error);
      });
    }
  } catch (error) {
    console.error(`Falha ao iniciar ${name}:`, error);
  }
}

function initSalaHero() {
  const hero = document.querySelector('.sala-hero');
  if (!hero) return;

  const revealTitle = () => hero.classList.add('is-title-risen');
  if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
    revealTitle();
    return;
  }

  const observer = new IntersectionObserver(([entry]) => {
    hero.classList.toggle('is-title-risen', entry.isIntersecting);
  }, { threshold: .32 });
  observer.observe(hero);
}

function initialize() {
  if ('scrollRestoration' in history) history.scrollRestoration = 'manual';
  window.scrollTo(0, 0);
  applySiteConfig();
  safely('mascote virtual', initMascotWidget);
  safely('introdução', initIntro);
  safely('navegação', initNavigation);
  safely('hero da Sala São Paulo', initSalaHero);
  safely('linha do tempo', initTimeline);
  safely('orquestra', initOrchestra);
  safely('famílias', initFamilies);
  safely('explorador tridimensional', initExplorer);
  safely('modo apresentação', initPresentation);
  safely('conceitos de onda', initBasicWave);
  safely('laboratórios matemáticos', initMathLabs);
  safely('comparador científico', initComparator);
  safely('laboratório do som', initSoundLab);
  safely('laboratório acústico', initHallAcoustics);
  safely('experimento', initExperiment);

  document.documentElement.classList.add('js-ready');
  window.addEventListener('error', event => {
    if (String(event.message || '').includes('ResizeObserver loop')) return;
    console.error(event.error || event.message);
  });

}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initialize, { once: true });
} else {
  initialize();
}
