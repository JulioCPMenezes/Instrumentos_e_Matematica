import {
  stringWaveSpeed,
  stringFrequency,
  nearestNote,
  fretPosition,
  remainingStringLength,
  equalTemperamentFrequency,
  speedOfSound,
  openTubeFrequency,
  closedTubeFrequency,
  brassAddedLength,
  barFrequency,
  membraneFrequency,
  helmholtzFrequency,
  wavelength,
  formatNumber,
  clamp
} from '../math/core.js';
import { audioEngine } from '../audio/AudioEngine.js';
import { prepareCanvas, drawGrid, drawAxes, mapRange } from '../utils/canvas.js';
import { showToast } from './layout.js';

const $ = (selector, scope = document) => scope.querySelector(selector);
const $$ = (selector, scope = document) => [...scope.querySelectorAll(selector)];

function text(element, value) {
  if (element) element.textContent = value;
}

export function initMathLabs() {
  const tabs = $$('[data-lab]');
  const panels = $$('[data-lab-panel]');
  tabs.forEach(tab => tab.addEventListener('click', () => {
    const key = tab.dataset.lab;
    tabs.forEach(item => {
      const active = item === tab;
      item.classList.toggle('active', active);
      item.setAttribute('aria-selected', String(active));
    });
    panels.forEach(panel => {
      const active = panel.dataset.labPanel === key;
      panel.classList.toggle('active', active);
      panel.hidden = !active;
    });
    window.dispatchEvent(new Event('resize'));
  }));

  const cleanups = [
    initStringLab(),
    initFretLab(),
    initTubeLab(),
    initBrassLab(),
    initBarLab(),
    initMembraneLab(),
    initHelmholtzLab()
  ].filter(Boolean);
  return () => cleanups.forEach(cleanup => cleanup?.());
}

function initStringLab() {
  const lengthInput = $('#string-length');
  const tensionInput = $('#string-tension');
  const densityInput = $('#string-density');
  const harmonicInput = $('#string-harmonic');
  const canvas = $('#string-canvas');
  if (!lengthInput || !canvas) return null;

  let phase = 0;
  let state = null;
  let active = true;

  const update = () => {
    const lengthM = Number(lengthInput.value) / 100;
    const tensionN = Number(tensionInput.value);
    const linearDensityKgM = Number(densityInput.value) / 10000;
    const harmonic = Number(harmonicInput.value);
    const speed = stringWaveSpeed(tensionN, linearDensityKgM);
    const frequency = stringFrequency({ lengthM, tensionN, linearDensityKgM, harmonic });
    const note = nearestNote(frequency);
    state = { lengthM, tensionN, linearDensityKgM, harmonic, speed, frequency, note };

    text($('#string-length-out'), `${formatNumber(lengthM, 2)} m`);
    text($('#string-tension-out'), `${formatNumber(tensionN, 0)} N`);
    text($('#string-density-out'), `${formatNumber(linearDensityKgM, 4)} kg/m`);
    text($('#string-harmonic-out'), String(harmonic));
    text($('#string-speed-result'), `${formatNumber(speed, 1)} m/s`);
    text($('#string-frequency-result'), `${formatNumber(frequency, 1)} Hz`);
    text($('#string-note-result'), note.name);
    text($('#string-cents-result'), `${note.cents >= 0 ? '+' : ''}${formatNumber(note.cents, 1)} cents`);
  };

  const draw = () => {
    if (!active) return;
    const prepared = prepareCanvas(canvas);
    if (prepared && state) {
      const { context, width, height } = prepared;
      drawGrid(context, width, height, { color: 'rgba(255,255,255,.05)', step: 24 });
      const left = 30;
      const right = width - 30;
      const center = height / 2;
      const amplitude = Math.min(height * 0.31, 70) * Math.min(1, 0.7 + state.tensionN / 600);
      context.strokeStyle = 'rgba(255,255,255,.25)';
      context.lineWidth = 7;
      context.beginPath();
      context.moveTo(left, center - 48);
      context.lineTo(left, center + 48);
      context.moveTo(right, center - 48);
      context.lineTo(right, center + 48);
      context.stroke();

      context.strokeStyle = '#e3c679';
      context.lineWidth = 3;
      context.shadowColor = 'rgba(227,198,121,.5)';
      context.shadowBlur = 12;
      context.beginPath();
      for (let x = left; x <= right; x += 2) {
        const t = (x - left) / Math.max(1, right - left);
        const envelope = Math.sin(Math.PI * state.harmonic * t);
        const y = center + envelope * Math.sin(phase) * amplitude;
        if (x === left) context.moveTo(x, y);
        else context.lineTo(x, y);
      }
      context.stroke();
      context.shadowBlur = 0;

      context.fillStyle = 'rgba(255,255,255,.65)';
      context.font = '12px system-ui';
      context.fillText(`L = ${formatNumber(state.lengthM, 2)} m`, left, height - 20);
      context.textAlign = 'right';
      context.fillText(`n = ${state.harmonic}`, right, height - 20);
      context.textAlign = 'left';
    }
    phase += Math.min(0.48, 0.06 + (state?.frequency || 100) / 1800);
    requestAnimationFrame(draw);
  };

  [lengthInput, tensionInput, densityInput, harmonicInput].forEach(input => input.addEventListener('input', update));
  $$('[data-string-challenge]').forEach(button => button.addEventListener('click', () => {
    const currentFrequency = state.frequency;
    if (button.dataset.stringChallenge === 'half') lengthInput.value = Math.max(Number(lengthInput.min), Math.round(Number(lengthInput.value) / 2));
    if (button.dataset.stringChallenge === 'tension4') tensionInput.value = Math.min(Number(tensionInput.max), Number(tensionInput.value) * 4);
    if (button.dataset.stringChallenge === 'density4') densityInput.value = Math.min(Number(densityInput.max), Number(densityInput.value) * 4);
    update();
    const ratio = state.frequency / currentFrequency;
    showToast(`A nova frequência é ${formatNumber(ratio, 2)}× a anterior.`);
  }));
  $('#string-play')?.addEventListener('click', () => audioEngine.tone(state.frequency, { type: 'sine', gain: 0.08 }).catch(error => showToast(error.message)));
  update();
  draw();
  return () => { active = false; };
}

function initFretLab() {
  const scaleInput = $('#fret-scale');
  const countInput = $('#fret-count');
  const baseInput = $('#fret-base');
  const canvas = $('#fret-canvas');
  const tableBody = $('#fret-table');
  if (!scaleInput || !canvas) return null;

  const update = () => {
    const scale = Number(scaleInput.value);
    const count = Number(countInput.value);
    const baseFrequency = Number(baseInput.value);
    text($('#fret-scale-out'), `${formatNumber(scale, 0)} mm`);
    text($('#fret-count-out'), String(count));
    text($('#fret-base-out'), `${formatNumber(baseFrequency, 0)} Hz`);

    const prepared = prepareCanvas(canvas);
    if (prepared) {
      const { context, width, height } = prepared;
      context.fillStyle = '#1a0e09';
      context.fillRect(20, height * 0.25, width - 40, height * 0.5);
      const gradient = context.createLinearGradient(20, 0, width - 20, 0);
      gradient.addColorStop(0, '#6c331a');
      gradient.addColorStop(0.5, '#a85a2b');
      gradient.addColorStop(1, '#6a3017');
      context.fillStyle = gradient;
      context.fillRect(28, height * 0.31, width - 56, height * 0.38);
      context.strokeStyle = 'rgba(238,223,193,.72)';
      context.lineWidth = 1;
      for (let string = 0; string < 6; string += 1) {
        const y = height * 0.36 + string * height * 0.055;
        context.beginPath();
        context.moveTo(28, y);
        context.lineTo(width - 28, y);
        context.stroke();
      }
      context.strokeStyle = '#e2c981';
      context.lineWidth = 2;
      for (let fret = 0; fret <= count; fret += 1) {
        const position = fretPosition(scale, fret);
        const x = mapRange(position, 0, scale, 28, width - 28);
        context.beginPath();
        context.moveTo(x, height * 0.31);
        context.lineTo(x, height * 0.69);
        context.stroke();
        if ([3, 5, 7, 9, 12, 15, 17, 19, 21, 24].includes(fret)) {
          context.fillStyle = fret === 12 ? '#e3c679' : 'rgba(255,255,255,.55)';
          context.beginPath();
          context.arc(x - (fret === count ? 2 : 6), height * 0.5, 3.5, 0, Math.PI * 2);
          context.fill();
        }
      }
      context.fillStyle = 'rgba(255,255,255,.72)';
      context.font = '12px system-ui';
      context.fillText('pestana', 28, height * 0.2);
      context.textAlign = 'right';
      context.fillText(`escala = ${scale} mm`, width - 28, height * 0.84);
      context.textAlign = 'left';
    }

    if (tableBody) {
      let previousPosition = 0;
      tableBody.innerHTML = Array.from({ length: count + 1 }, (_, fret) => {
        const position = fretPosition(scale, fret);
        const space = fret === 0 ? 0 : position - previousPosition;
        previousPosition = position;
        const frequency = equalTemperamentFrequency(baseFrequency, fret);
        const note = nearestNote(frequency);
        return `<tr><td>${fret}</td><td>${formatNumber(position, 2)} mm</td><td>${fret === 0 ? '—' : `${formatNumber(space, 2)} mm`}</td><td>${formatNumber(frequency, 2)} Hz</td><td>${note.name}</td></tr>`;
      }).join('');
    }
  };

  [scaleInput, countInput, baseInput].forEach(input => input.addEventListener('input', update));
  window.addEventListener('resize', update);
  update();
  return () => window.removeEventListener('resize', update);
}

function initTubeLab() {
  const lengthInput = $('#tube-length');
  const temperatureInput = $('#tube-temperature');
  const modeInput = $('#tube-mode');
  const canvas = $('#tube-canvas');
  if (!lengthInput || !canvas) return null;
  let state = null;
  let phase = 0;
  let active = true;

  const update = () => {
    const lengthM = Number(lengthInput.value) / 100;
    const temperatureC = Number(temperatureInput.value);
    const mode = Number(modeInput.value);
    const type = $('input[name="tube-type"]:checked')?.value || 'open';
    const speed = speedOfSound(temperatureC);
    const frequency = type === 'open'
      ? openTubeFrequency({ lengthM, temperatureC, mode })
      : closedTubeFrequency({ lengthM, temperatureC, mode });
    const note = nearestNote(frequency);
    state = { lengthM, temperatureC, mode, type, speed, frequency, note, wavelength: wavelength(frequency, speed) };
    text($('#tube-length-out'), `${formatNumber(lengthM, 2)} m`);
    text($('#tube-temperature-out'), `${formatNumber(temperatureC, 0)} °C`);
    text($('#tube-mode-out'), String(mode));
    text($('#tube-speed-result'), `${formatNumber(speed, 1)} m/s`);
    text($('#tube-frequency-result'), `${formatNumber(frequency, 1)} Hz`);
    text($('#tube-note-result'), note.name);
    text($('#tube-wavelength-result'), `${formatNumber(state.wavelength, 2)} m`);
  };

  const draw = () => {
    if (!active) return;
    const prepared = prepareCanvas(canvas);
    if (prepared && state) {
      const { context, width, height } = prepared;
      drawGrid(context, width, height, { color: 'rgba(255,255,255,.045)', step: 24 });
      const left = 45;
      const right = width - 45;
      const center = height / 2;
      context.strokeStyle = 'rgba(227,198,121,.8)';
      context.lineWidth = 7;
      context.beginPath();
      context.moveTo(left, center - 72);
      context.lineTo(right, center - 72);
      context.moveTo(left, center + 72);
      context.lineTo(right, center + 72);
      if (state.type === 'closed') {
        context.moveTo(left, center - 72);
        context.lineTo(left, center + 72);
      }
      context.stroke();
      context.strokeStyle = '#70b7dc';
      context.lineWidth = 3;
      context.beginPath();
      const cycles = state.type === 'open' ? state.mode : (2 * state.mode - 1) / 2;
      for (let x = left; x <= right; x += 2) {
        const t = (x - left) / (right - left);
        let shape;
        if (state.type === 'open') shape = Math.cos(Math.PI * state.mode * t);
        else shape = Math.sin(Math.PI * (state.mode - 0.5) * t);
        const y = center + shape * Math.sin(phase) * 60;
        if (x === left) context.moveTo(x, y);
        else context.lineTo(x, y);
      }
      context.stroke();
      context.fillStyle = 'rgba(255,255,255,.58)';
      context.font = '12px system-ui';
      context.fillText(state.type === 'open' ? 'aberto' : 'fechado', left, 24);
      context.textAlign = 'right';
      context.fillText(`${formatNumber(cycles, 1)} meia(s) onda(s) no tubo`, right, 24);
      context.textAlign = 'left';
    }
    phase += 0.13;
    requestAnimationFrame(draw);
  };

  [lengthInput, temperatureInput, modeInput].forEach(input => input.addEventListener('input', update));
  $$('input[name="tube-type"]').forEach(input => input.addEventListener('change', update));
  $('#tube-play')?.addEventListener('click', () => audioEngine.tone(state.frequency, { type: state.type === 'closed' ? 'square' : 'sine', gain: 0.06 }).catch(error => showToast(error.message)));
  update();
  draw();
  return () => { active = false; };
}

function initBrassLab() {
  const lengthInput = $('#brass-length');
  const semitonesInput = $('#brass-semitones');
  const diagram = $('#brass-diagram');
  if (!lengthInput) return null;
  const update = () => {
    const baseLength = Number(lengthInput.value) / 100;
    const semitones = Number(semitonesInput.value);
    const added = brassAddedLength(baseLength, semitones);
    const total = baseLength + added;
    const percent = added / baseLength * 100;
    const frequencyRatio = 2 ** (-semitones / 12);
    text($('#brass-length-out'), `${formatNumber(baseLength, 2)} m`);
    text($('#brass-semitones-out'), `${semitones} ${semitones === 1 ? 'semitom' : 'semitons'}`);
    text($('#brass-added-result'), `${formatNumber(added, 3)} m`);
    text($('#brass-total-result'), `${formatNumber(total, 3)} m`);
    text($('#brass-percent-result'), `${formatNumber(percent, 2)}%`);
    text($('#brass-ratio-result'), `${formatNumber(frequencyRatio, 3)} × f₀`);
    if (diagram) diagram.style.setProperty('--extension-width', `${clamp(12 + percent * 0.95, 12, 45)}%`);
  };
  [lengthInput, semitonesInput].forEach(input => input.addEventListener('input', update));
  update();
  return null;
}

const barMaterials = {
  rosewood: { name: 'madeira rígida', E: 16e9, rho: 850 },
  aluminum: { name: 'alumínio', E: 69e9, rho: 2700 },
  steel: { name: 'aço', E: 200e9, rho: 7850 }
};

function initBarLab() {
  const lengthInput = $('#bar-length');
  const thicknessInput = $('#bar-thickness');
  const materialSelect = $('#bar-material');
  const canvas = $('#bar-canvas');
  if (!lengthInput || !canvas) return null;
  let phase = 0;
  let state = null;
  let active = true;

  const update = () => {
    const lengthM = Number(lengthInput.value) / 100;
    const thicknessM = Number(thicknessInput.value) / 1000;
    const material = barMaterials[materialSelect.value];
    const frequency = barFrequency({ lengthM, thicknessM, youngModulusPa: material.E, densityKgM3: material.rho });
    const note = nearestNote(frequency);
    state = { lengthM, thicknessM, material, frequency, note };
    text($('#bar-length-out'), `${formatNumber(lengthM, 2)} m`);
    text($('#bar-thickness-out'), `${formatNumber(thicknessM * 1000, 0)} mm`);
    text($('#bar-frequency-result'), `${formatNumber(frequency, 1)} Hz`);
    text($('#bar-note-result'), note.name);
    text($('#bar-inverse-result'), `${formatNumber(1 / lengthM ** 2, 2)} m⁻²`);
  };

  const draw = () => {
    if (!active) return;
    const prepared = prepareCanvas(canvas);
    if (prepared && state) {
      const { context, width, height } = prepared;
      drawGrid(context, width, height, { color: 'rgba(255,255,255,.045)', step: 24 });
      const left = width * 0.12;
      const right = width * 0.88;
      const center = height * 0.5;
      const barHeight = clamp(state.thicknessM * 1800, 12, 44);
      const amplitude = 32;
      const gradient = context.createLinearGradient(left, 0, right, 0);
      gradient.addColorStop(0, '#6f3518');
      gradient.addColorStop(0.5, '#c57932');
      gradient.addColorStop(1, '#5e2a13');
      context.strokeStyle = gradient;
      context.lineWidth = barHeight;
      context.lineCap = 'round';
      context.beginPath();
      for (let x = left; x <= right; x += 2) {
        const t = (x - left) / (right - left);
        const modeShape = Math.cosh(4.73 * (t - 0.5)) / Math.cosh(2.365) - Math.cos(Math.PI * 2 * (t - 0.5));
        const normalized = modeShape / 2.2;
        const y = center + normalized * Math.sin(phase) * amplitude;
        if (x === left) context.moveTo(x, y);
        else context.lineTo(x, y);
      }
      context.stroke();
      context.fillStyle = '#e3c679';
      [0.224, 0.776].forEach(t => {
        const x = left + (right - left) * t;
        context.beginPath();
        context.arc(x, center + 45, 7, 0, Math.PI * 2);
        context.fill();
      });
      context.fillStyle = 'rgba(255,255,255,.55)';
      context.font = '12px system-ui';
      context.fillText('apoios próximos dos nós', left, height - 20);
    }
    phase += 0.14;
    requestAnimationFrame(draw);
  };

  [lengthInput, thicknessInput, materialSelect].forEach(input => input.addEventListener('input', update));
  update();
  draw();
  return () => { active = false; };
}

function initMembraneLab() {
  const radiusInput = $('#membrane-radius');
  const tensionInput = $('#membrane-tension');
  const densityInput = $('#membrane-density');
  const modeSelect = $('#membrane-mode');
  const canvas = $('#membrane-canvas');
  if (!radiusInput || !canvas) return null;
  let phase = 0;
  let state = null;
  let active = true;

  const update = () => {
    const radiusM = Number(radiusInput.value) / 100;
    const tensionPerLength = Number(tensionInput.value);
    const surfaceDensity = Number(densityInput.value) / 100;
    const frequency = membraneFrequency({ radiusM, tensionPerLength, surfaceDensity });
    const note = nearestNote(frequency);
    state = { radiusM, tensionPerLength, surfaceDensity, frequency, note, mode: modeSelect.value };
    text($('#membrane-radius-out'), `${formatNumber(radiusM, 2)} m`);
    text($('#membrane-tension-out'), `${formatNumber(tensionPerLength, 0)} N/m`);
    text($('#membrane-density-out'), `${formatNumber(surfaceDensity, 2)} kg/m²`);
    text($('#membrane-frequency-result'), `${formatNumber(frequency, 1)} Hz`);
    text($('#membrane-note-result'), note.name);
    text($('#membrane-radius-result'), `${formatNumber(radiusM, 2)} m`);
  };

  const draw = () => {
    if (!active) return;
    const prepared = prepareCanvas(canvas);
    if (prepared && state) {
      const { context, width, height } = prepared;
      const centerX = width / 2;
      const centerY = height / 2;
      const radius = Math.min(width, height) * 0.34;
      const gradient = context.createRadialGradient(centerX - radius * 0.3, centerY - radius * 0.35, 0, centerX, centerY, radius);
      gradient.addColorStop(0, '#f3e6c8');
      gradient.addColorStop(0.7, '#b98b58');
      gradient.addColorStop(1, '#5d2d19');
      context.fillStyle = gradient;
      context.beginPath();
      context.arc(centerX, centerY, radius, 0, Math.PI * 2);
      context.fill();
      context.strokeStyle = '#e3c679';
      context.lineWidth = 8;
      context.stroke();

      const intensity = 0.3 + 0.25 * Math.sin(phase);
      context.strokeStyle = `rgba(50,70,96,${0.55 + intensity})`;
      context.lineWidth = 2.5;
      if (state.mode === '11' || state.mode === '21') {
        const count = state.mode === '21' ? 2 : 1;
        for (let i = 0; i < count; i += 1) {
          const angle = i * Math.PI / count + phase * 0.05;
          context.beginPath();
          context.moveTo(centerX - Math.cos(angle) * radius, centerY - Math.sin(angle) * radius);
          context.lineTo(centerX + Math.cos(angle) * radius, centerY + Math.sin(angle) * radius);
          context.stroke();
        }
      }
      if (state.mode === '02') {
        context.beginPath();
        context.arc(centerX, centerY, radius * 0.55, 0, Math.PI * 2);
        context.stroke();
      }
      context.fillStyle = `rgba(123,44,66,${0.18 + 0.18 * Math.sin(phase)})`;
      context.beginPath();
      context.arc(centerX, centerY, radius * (0.42 + Math.sin(phase) * 0.03), 0, Math.PI * 2);
      context.fill();
    }
    phase += 0.07;
    requestAnimationFrame(draw);
  };

  [radiusInput, tensionInput, densityInput, modeSelect].forEach(input => input.addEventListener('input', update));
  $('#membrane-play')?.addEventListener('click', () => audioEngine.tone(state.frequency, { type: 'triangle', gain: 0.08, duration: 1.3 }).catch(error => showToast(error.message)));
  update();
  draw();
  return () => { active = false; };
}

function initHelmholtzLab() {
  const areaInput = $('#helm-area');
  const volumeInput = $('#helm-volume');
  const neckInput = $('#helm-neck');
  const visual = $('#resonator-visual');
  if (!areaInput) return null;
  let state = null;
  const update = () => {
    const areaCm2 = Number(areaInput.value);
    const volumeL = Number(volumeInput.value);
    const neckCm = Number(neckInput.value) / 10;
    const frequency = helmholtzFrequency({ openingAreaM2: areaCm2 / 10000, volumeM3: volumeL / 1000, effectiveNeckLengthM: neckCm / 100 });
    const note = nearestNote(frequency);
    state = { areaCm2, volumeL, neckCm, frequency, note };
    text($('#helm-area-out'), `${formatNumber(areaCm2, 0)} cm²`);
    text($('#helm-volume-out'), `${formatNumber(volumeL, 0)} L`);
    text($('#helm-neck-out'), `${formatNumber(neckCm, 1)} cm`);
    text($('#helm-frequency-result'), `${formatNumber(frequency, 1)} Hz`);
    text($('#helm-note-result'), note.name);
    text($('#helm-volume-result'), `${formatNumber(volumeL, 1)} L`);
    text($('#helm-area-result'), `${formatNumber(areaCm2, 1)} cm²`);
    if (visual) {
      visual.style.setProperty('--resonator-width', `${clamp(120 + Math.sqrt(volumeL) * 12, 130, 250)}px`);
      visual.style.setProperty('--resonator-height', `${clamp(150 + Math.sqrt(volumeL) * 13, 170, 280)}px`);
      visual.style.setProperty('--resonator-opening', `${clamp(24 + Math.sqrt(areaCm2) * 5, 28, 85)}px`);
    }
  };
  [areaInput, volumeInput, neckInput].forEach(input => input.addEventListener('input', update));
  $('#helm-play')?.addEventListener('click', () => audioEngine.tone(state.frequency, { type: 'sine', gain: 0.09, duration: 1.25 }).catch(error => showToast(error.message)));
  update();
  return null;
}

export function initComparator() {
  const tabs = $$('[data-compare]');
  const canvas = $('#comparator-canvas');
  const measureInput = $('#comparator-measure');
  const title = $('#comparator-title');
  const description = $('#comparator-description');
  const formula = $('#comparator-formula');
  if (!canvas || !measureInput) return;

  const configs = {
    strings: {
      title: 'Cordas: f ∝ 1/L', formula: 'f ∝ 1/L', unit: 'm', min: 20, max: 120, value: 65,
      description: 'Tensão e densidade linear ficam constantes; apenas o comprimento muda.',
      compute: cm => stringFrequency({ lengthM: cm / 100, tensionN: 80, linearDensityKgM: 0.003 })
    },
    tubes: {
      title: 'Tubos abertos: f ∝ 1/L', formula: 'f = v/(2L)', unit: 'm', min: 20, max: 200, value: 65,
      description: 'Temperatura e tipo de tubo ficam constantes; apenas o comprimento acústico muda.',
      compute: cm => openTubeFrequency({ lengthM: cm / 100, temperatureC: 20, mode: 1 })
    },
    bars: {
      title: 'Barras uniformes: f ∝ 1/L²', formula: 'f ≈ 1,028 · h/L² · √(E/ρ)', unit: 'm', min: 15, max: 80, value: 32,
      description: 'Material e espessura ficam constantes; apenas o comprimento da barra muda.',
      compute: cm => barFrequency({ lengthM: cm / 100, thicknessM: 0.018, youngModulusPa: 16e9, densityKgM3: 850 })
    },
    membranes: {
      title: 'Membranas: f ∝ 1/r', formula: 'f₀₁ ≈ 0,3827/r · √(S/σ)', unit: 'm', min: 15, max: 65, value: 35,
      description: 'Tensão e densidade superficial ficam constantes; apenas o raio muda.',
      compute: cm => membraneFrequency({ radiusM: cm / 100, tensionPerLength: 1600, surfaceDensity: 0.5 })
    }
  };
  let current = 'strings';

  const draw = () => {
    const config = configs[current];
    const prepared = prepareCanvas(canvas);
    if (!prepared) return;
    const { context, width, height } = prepared;
    context.fillStyle = '#fbf8f1';
    context.fillRect(0, 0, width, height);
    drawGrid(context, width, height, { color: 'rgba(30,53,87,.06)', step: 32 });
    drawAxes(context, width, height, { color: 'rgba(30,53,87,.28)', padding: 48 });
    const samples = Array.from({ length: 60 }, (_, index) => {
      const measure = config.min + (config.max - config.min) * index / 59;
      return { measure, frequency: config.compute(measure) };
    });
    const maxFrequency = Math.max(...samples.map(point => point.frequency));
    const minFrequency = Math.min(...samples.map(point => point.frequency));
    const toX = value => mapRange(value, config.min, config.max, 48, width - 34);
    const toY = value => mapRange(value, minFrequency, maxFrequency, height - 48, 30);
    context.strokeStyle = '#7b2c42';
    context.lineWidth = 3;
    context.beginPath();
    samples.forEach((point, index) => {
      const x = toX(point.measure);
      const y = toY(point.frequency);
      if (index === 0) context.moveTo(x, y);
      else context.lineTo(x, y);
    });
    context.stroke();
    const currentMeasure = Number(measureInput.value);
    const currentFrequency = config.compute(currentMeasure);
    context.fillStyle = '#c8a24a';
    context.beginPath();
    context.arc(toX(currentMeasure), toY(currentFrequency), 7, 0, Math.PI * 2);
    context.fill();
    context.strokeStyle = '#fff';
    context.lineWidth = 3;
    context.stroke();
    context.fillStyle = '#655f56';
    context.font = '12px system-ui';
    context.textAlign = 'center';
    context.fillText(`dimensão (${config.unit})`, width / 2, height - 10);
    context.save();
    context.translate(14, height / 2);
    context.rotate(-Math.PI / 2);
    context.fillText('frequência (Hz)', 0, 0);
    context.restore();
    context.textAlign = 'left';
    context.fillStyle = '#1e3557';
    context.font = '700 13px system-ui';
    context.fillText(`${formatNumber(currentFrequency, 1)} Hz`, Math.min(width - 95, toX(currentMeasure) + 12), Math.max(25, toY(currentFrequency) - 12));
    text($('#comparator-measure-out'), `${formatNumber(currentMeasure / 100, 2)} ${config.unit}`);
  };

  const select = key => {
    current = key;
    const config = configs[key];
    measureInput.min = config.min;
    measureInput.max = config.max;
    measureInput.value = config.value;
    text(title, config.title);
    text(description, config.description);
    text(formula, config.formula);
    tabs.forEach(tab => tab.classList.toggle('active', tab.dataset.compare === key));
    draw();
  };
  tabs.forEach(tab => tab.addEventListener('click', () => select(tab.dataset.compare)));
  measureInput.addEventListener('input', draw);
  window.addEventListener('resize', draw);
  select('strings');
}
