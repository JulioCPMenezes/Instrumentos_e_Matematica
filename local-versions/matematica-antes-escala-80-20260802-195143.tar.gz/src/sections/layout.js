import { siteConfig } from '../data/siteConfig.js';
import { timeline } from '../data/timeline.js';
import { familias } from '../data/familias.js';
import { instrumentos } from '../data/instrumentos.js';
import { audioEngine } from '../audio/AudioEngine.js';
import { initStage, initInstrumentExplorer, initMascot } from '../three/scenes.js';
import { prepareCanvas } from '../utils/canvas.js';

const $ = (selector, scope = document) => scope.querySelector(selector);
const $$ = (selector, scope = document) => [...scope.querySelectorAll(selector)];

let toastTimer;
export function showToast(message) {
  const toast = $('#toast');
  if (!toast) return;
  window.clearTimeout(toastTimer);
  toast.textContent = message;
  toast.classList.add('is-visible');
  toastTimer = window.setTimeout(() => toast.classList.remove('is-visible'), 2800);
}

export function applySiteConfig() {
  $$('[data-config]').forEach(element => {
    const key = element.dataset.config;
    if (Object.prototype.hasOwnProperty.call(siteConfig, key)) {
      element.textContent = siteConfig[key];
    }
  });
}

export async function initIntro() {
  const intro = $('#intro');
  const trigger = $('#intro-trigger');
  const canvas = $('#intro-stage');
  if (!intro || !trigger || !canvas) return null;

  document.body.classList.add('intro-active');
  intro.classList.remove('is-open');
  let stage = { reveal() {}, dispose() {}, mode: 'loading' };
  let opened = false;
  const stagePromise = initStage(canvas).then(instance => {
    stage = instance || stage;
    intro.dataset.renderMode = stage.mode || 'fallback';
    if (opened) stage.reveal?.();
    return stage;
  });

  const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  const openCurtains = () => {
    if (opened) return;
    opened = true;
    intro.classList.add('is-open');
    trigger.disabled = true;
    trigger.setAttribute('aria-hidden', 'true');
    stage.reveal?.();
    audioEngine.chord([146.83, 220, 293.66, 369.99], reducedMotion ? 0.8 : 1.75).catch(() => {});

    window.setTimeout(() => {
      document.body.classList.remove('intro-active');
      document.body.classList.add('experience-started');
      window.dispatchEvent(new CustomEvent('experience-started'));
      intro.querySelector('.intro-scroll')?.classList.add('is-ready');
    }, reducedMotion ? 120 : 2050);
  };

  trigger.addEventListener('pointerdown', () => intro.classList.add('is-pressed'));
  trigger.addEventListener('pointerup', () => intro.classList.remove('is-pressed'));
  trigger.addEventListener('pointercancel', () => intro.classList.remove('is-pressed'));
  trigger.addEventListener('pointerleave', () => intro.classList.remove('is-pressed'));
  trigger.addEventListener('click', openCurtains, { once: true });
  intro.addEventListener('click', openCurtains);
  trigger.addEventListener('keydown', event => {
    if (event.key === 'Enter' || event.key === ' ') {
      event.preventDefault();
      openCurtains();
    }
  });

  return stagePromise;
}

export function initMascotWidget() {
  const widget = $('#mascot-widget');
  const canvas = $('#mascot-canvas');
  if (!widget || !canvas) return null;

  const voice = new Audio('./public/assets/audio/marcio_oi_gente_1.ogg');
  voice.preload = 'auto';
  voice.volume = 0.86;
  let scene = null;
  let started = false;

  const playVoice = async () => {
    if (!audioEngine.enabled) {
      showToast('Ative o som no menu para ouvir o professor Marcio.');
      return;
    }
    try {
      voice.pause();
      voice.currentTime = 0;
      await voice.play();
      widget.classList.add('is-speaking');
      const finish = () => widget.classList.remove('is-speaking');
      voice.addEventListener('ended', finish, { once: true });
      window.setTimeout(finish, 1800);
    } catch {
      showToast('Clique novamente no mascote para ouvir o áudio.');
    }
  };

  const isMascotHit = event => {
    const rect = canvas.getBoundingClientRect();
    const x = (event.clientX - rect.left) / rect.width;
    const y = (event.clientY - rect.top) / rect.height;
    return x >= 0.28 && x <= 0.72 && y >= 0.18 && y <= 0.70;
  };

  const start = async () => {
    if (started) return;
    started = true;
    widget.hidden = false;
    widget.removeAttribute('hidden');
    requestAnimationFrame(() => widget.classList.add('is-visible'));
    scene = await initMascot(canvas);
  };

  widget.addEventListener('click', event => {
    if (!event.shiftKey && isMascotHit(event)) playVoice();
  });
  start();
  window.addEventListener('audio-setting-changed', event => {
    if (!event.detail?.enabled) {
      voice.pause();
      widget.classList.remove('is-speaking');
    }
  });
  window.addEventListener('pagehide', () => {
    voice.pause();
    scene?.dispose?.();
  }, { once: true });

  return { start, playVoice };
}

export function initNavigation() {
  const navToggle = $('#nav-toggle');
  const navMenu = $('#nav-menu');
  const progress = $('#reading-progress');
  const navLinks = $$('.nav-menu a');
  const sections = $$('main .section[id]');

  navToggle?.addEventListener('click', () => {
    const expanded = navToggle.getAttribute('aria-expanded') === 'true';
    navToggle.setAttribute('aria-expanded', String(!expanded));
    navMenu?.classList.toggle('is-open', !expanded);
  });

  navLinks.forEach(link => link.addEventListener('click', () => {
    navMenu?.classList.remove('is-open');
    navToggle?.setAttribute('aria-expanded', 'false');
  }));

  const updateProgress = () => {
    const scrollable = document.documentElement.scrollHeight - window.innerHeight;
    const percentage = scrollable > 0 ? Math.min(100, Math.max(0, window.scrollY / scrollable * 100)) : 0;
    if (progress) progress.style.width = `${percentage}%`;
  };
  window.addEventListener('scroll', updateProgress, { passive: true });
  updateProgress();

  const linkByTarget = new Map(navLinks.map(link => [link.getAttribute('href')?.slice(1), link]));
  const observer = new IntersectionObserver(entries => {
    const visible = entries
      .filter(entry => entry.isIntersecting)
      .sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];
    if (!visible) return;
    navLinks.forEach(link => link.classList.remove('active'));
    linkByTarget.get(visible.target.id)?.classList.add('active');
  }, { rootMargin: '-25% 0px -60% 0px', threshold: [0.08, 0.25, 0.5] });
  sections.forEach(section => observer.observe(section));

  const revealObserver = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('is-visible');
        revealObserver.unobserve(entry.target);
      }
    });
  }, { threshold: 0.12, rootMargin: '0px 0px -6% 0px' });
  $$('.reveal').forEach(item => revealObserver.observe(item));

  const soundToggle = $('#sound-toggle');
  soundToggle?.addEventListener('click', () => {
    const enabled = soundToggle.getAttribute('aria-pressed') !== 'true';
    soundToggle.setAttribute('aria-pressed', String(enabled));
    soundToggle.querySelector('.sr-only').textContent = enabled ? 'Som ativado' : 'Som desativado';
    soundToggle.querySelector('span[aria-hidden]').textContent = enabled ? '♪' : '×';
    audioEngine.setEnabled(enabled);
    if (!enabled) audioEngine.stopAll();
    window.dispatchEvent(new CustomEvent('audio-setting-changed', { detail: { enabled } }));
    showToast(enabled ? 'Som ativado.' : 'Som desativado.');
  });

  $('#stop-all-audio')?.addEventListener('click', () => {
    audioEngine.stopAll();
    showToast('Todos os sons foram interrompidos.');
  });
}



export function initTimeline() {
  const rail = $('#timeline-rail');
  const preview = $('#timeline-preview');
  const previewImage = $('#timeline-preview-image');
  const previewPeriod = $('#timeline-preview-period');
  const previewTitle = $('#timeline-preview-title');
  const previewText = $('#timeline-preview-text');
  const openButton = $('#timeline-open');
  const dialog = $('#timeline-dialog');
  if (!rail || !preview || !dialog) return;

  const dialogImage = $('#timeline-dialog-image');
  const dialogPeriod = $('#timeline-dialog-period');
  const dialogTitle = $('#timeline-dialog-title');
  const dialogText = $('#timeline-dialog-text');
  const dialogFormula = $('#timeline-dialog-formula');
  const dialogMath = $('#timeline-dialog-math');
  const dialogAction = $('#timeline-dialog-action');
  const closeButton = $('#timeline-dialog-close');
  let activeIndex = 0;
  let previousFocus = null;

  rail.innerHTML = timeline.map((item, index) => `
    <button class="timeline-marker${index === 0 ? ' is-active' : ''}" data-timeline-index="${index}" role="listitem" type="button" aria-label="${item.periodo}: ${item.titulo}">
      <span class="timeline-dot" aria-hidden="true"></span>
      <span class="timeline-year">${item.periodo}</span>
      <span class="timeline-marker-title">${item.titulo}</span>
    </button>
  `).join('');

  const updatePreview = index => {
    activeIndex = Number(index);
    const item = timeline[activeIndex];
    if (!item) return;
    $$('.timeline-marker', rail).forEach((marker, markerIndex) => marker.classList.toggle('is-active', markerIndex === activeIndex));
    preview.classList.remove('is-changing');
    // Restart the entrance animation without delaying the information update.
    void preview.offsetWidth;
    preview.classList.add('is-changing');
    previewImage.src = item.imagem;
    previewImage.alt = `Ilustração de ${item.titulo}`;
    previewPeriod.textContent = item.periodo;
    previewTitle.textContent = item.titulo;
    previewText.textContent = item.texto;
  };

  const openDialog = index => {
    activeIndex = Number(index);
    const item = timeline[activeIndex];
    if (!item) return;
    previousFocus = document.activeElement;
    dialogImage.src = item.imagem;
    dialogImage.alt = `Ilustração de ${item.titulo}`;
    dialogPeriod.textContent = item.periodo;
    dialogTitle.textContent = item.titulo;
    dialogText.textContent = item.texto;
    dialogFormula.textContent = item.formula;
    dialogMath.innerHTML = item.matematica.map(word => `<span>${word}</span>`).join('');
    dialogAction.dataset.timelineAction = item.interacao;
    dialog.showModal();
  };

  $$('.timeline-marker', rail).forEach(marker => {
    const index = Number(marker.dataset.timelineIndex);
    marker.addEventListener('mouseenter', () => updatePreview(index));
    marker.addEventListener('focus', () => updatePreview(index));
    marker.addEventListener('click', () => openDialog(index));
  });

  openButton?.addEventListener('click', () => openDialog(activeIndex));
  closeButton?.addEventListener('click', () => dialog.close());
  dialog.addEventListener('click', event => {
    if (event.target === dialog) dialog.close();
  });
  dialog.addEventListener('close', () => previousFocus?.focus?.());
  dialogAction?.addEventListener('click', () => {
    const targetMap = {
      monocordio: '#matematica',
      temperamento: '#matematica',
      cordas: '#matematica',
      harmonicos: '#laboratorio-som',
      fourier: '#laboratorio-som',
      sabine: '#acustica',
      sala: '#acustica',
      produto: '#produto'
    };
    dialog.close();
    document.querySelector(targetMap[dialogAction.dataset.timelineAction] || '#matematica')?.scrollIntoView({ behavior: 'smooth' });
  });

  updatePreview(0);
}

export function initOrchestra() {
  const map = $('#orchestra-map');
  const panel = $('#orchestra-panel');
  if (!map || !panel) return;
  const familyOrder = ['cordas', 'madeiras', 'metais', 'percussao'];
  const render = key => {
    const family = familias[key];
    const index = familyOrder.indexOf(key) + 1;
    panel.innerHTML = `
      <span class="family-index">0${index}</span>
      <h3>${family.nome}</h3>
      <dl>
        <div><dt>O que vibra</dt><dd>${family.oQueVibra}</dd></div>
        <div><dt>Como começa</dt><dd>${family.inicio}</dd></div>
        <div><dt>Variáveis matemáticas</dt><dd>${family.variaveis}</dd></div>
      </dl>
      <div class="formula-display light">${family.formula}</div>
      <ul>${family.instrumentos.map(id => `<li>${instrumentos[id].nome}</li>`).join('')}</ul>
    `;
    $$('.orchestra-zone', map).forEach(zone => zone.classList.toggle('active', zone.dataset.family === key));
    map.classList.add('has-selection');
  };
  $$('.orchestra-zone', map).forEach(zone => {
    zone.addEventListener('click', () => render(zone.dataset.family));
    zone.addEventListener('mouseenter', () => render(zone.dataset.family));
  });
  render('cordas');
}

const instrumentAsset = name => `./public/assets/instrumentos/${name}`;

export function initFamilies() {
  const summary = $('#family-summary');
  const grid = $('#instrument-grid');
  const tabs = $$('[data-family-tab]');
  if (!summary || !grid) return;

  const render = key => {
    const family = familias[key];
    summary.innerHTML = `
      <div><p class="eyebrow" style="color:${family.cor}">Família selecionada</p><h3>${family.nome}</h3><p><b>O que vibra:</b> ${family.oQueVibra}.</p><p><b>Como a vibração começa:</b> ${family.inicio}</p><p>${family.explicacao}</p></div>
      <div class="family-formula"><small>Modelo matemático principal</small>${family.formula}<small>Variáveis: ${family.variaveis}</small></div>
    `;
    grid.innerHTML = family.instrumentos.map(id => {
      const instrument = instrumentos[id];
      return `
        <article class="instrument-card">
          <figure><img src="${instrumentAsset(instrument.imagem)}" alt="${instrument.nome}" loading="lazy"></figure>
          <div class="card-body">
            <span class="family-name">${family.nome}</span>
            <h3>${instrument.nome}</h3>
            <p>${instrument.producao}</p>
            <div class="instrument-metric"><span>${instrument.faixa}</span><span>${instrument.tamanho}</span><span>${instrument.matematica}</span></div>
            <p><b>Curiosidade:</b> ${instrument.curiosidade}</p>
            <div class="instrument-actions"><button type="button" data-instrument-play="${id}">Ouvir ${Math.round(instrument.demoHz)} Hz</button><button type="button" data-instrument-explore="${id}">Ver em 3D</button></div>
          </div>
        </article>
      `;
    }).join('');
    tabs.forEach(tab => {
      const active = tab.dataset.familyTab === key;
      tab.classList.toggle('active', active);
      tab.setAttribute('aria-selected', String(active));
    });
    $$('[data-instrument-play]', grid).forEach(button => {
      button.addEventListener('click', () => {
        const instrument = instrumentos[button.dataset.instrumentPlay];
        audioEngine.tone(instrument.demoHz, { type: key === 'metais' ? 'sawtooth' : key === 'percussao' ? 'triangle' : 'sine', gain: 0.09 }).catch(error => showToast(error.message));
      });
    });
    $$('[data-instrument-explore]', grid).forEach(button => {
      button.addEventListener('click', () => {
        const id = button.dataset.instrumentExplore;
        const map = { violino: 'violino', viola: 'violino', violoncelo: 'violino', contrabaixo: 'violino', piccolo: 'flauta', flauta: 'flauta', clarinete: 'flauta', fagote: 'flauta', trompete: 'trompete', trompa: 'trompete', trombone: 'trompete', tuba: 'trompete', timpano: 'timpano', xilofone: 'xilofone', triangulo: 'xilofone', celesta: 'xilofone' };
        window.dispatchEvent(new CustomEvent('instrument-explorer-select', { detail: map[id] }));
        $('#explorador-3d')?.scrollIntoView({ behavior: 'smooth' });
      });
    });
  };
  tabs.forEach(tab => tab.addEventListener('click', () => render(tab.dataset.familyTab)));
  render('cordas');
}

const explorerData = {
  violino: [
    ['L', 'Comprimento vibrante', 'Menor L → maior frequência.'],
    ['T', 'Tensão', 'Maior T → frequência maior pela raiz quadrada.'],
    ['μ', 'Massa por metro', 'Cordas mais pesadas favorecem frequências menores.'],
    ['R', 'Caixa', 'Ajuda a irradiar e colorir o som.']
  ],
  flauta: [
    ['L', 'Comprimento acústico', 'Abrir furos encurta aproximadamente a coluna de ar.'],
    ['v', 'Velocidade do som', 'Varia com a temperatura do ar.'],
    ['○', 'Furos e chaves', 'Posição e diâmetro corrigem as ressonâncias.'],
    ['G', 'Geometria', 'Diâmetro e extremidades alteram o modelo ideal.']
  ],
  trompete: [
    ['ΔL', 'Válvulas', 'Acrescentam diferentes comprimentos ao caminho do ar.'],
    ['L', 'Tubo', 'Maior comprimento favorece frequências menores.'],
    ['B', 'Bocal', 'Acopla a vibração dos lábios à coluna de ar.'],
    ['C', 'Campana', 'Modifica ressonâncias e radiação sonora.']
  ],
  timpano: [
    ['r', 'Raio', 'Mantendo o restante, a frequência varia aproximadamente com 1/r.'],
    ['S', 'Tensão', 'O pedal altera S e muda a afinação.'],
    ['σ', 'Densidade superficial', 'Membranas mais pesadas tendem a frequências menores.'],
    ['m,n', 'Modos', 'Círculos e linhas nodais formam padrões bidimensionais.']
  ],
  xilofone: [
    ['L²', 'Comprimento', 'A frequência de uma barra uniforme varia aproximadamente com 1/L².'],
    ['h', 'Espessura', 'Maior espessura aumenta a rigidez e a frequência do modelo.'],
    ['E/ρ', 'Material', 'Elasticidade e densidade participam do cálculo.'],
    ['N', 'Entalhe e apoio', 'Ajustam fundamental, parciais e amortecimento.']
  ]
};

export async function initExplorer() {
  const canvas = $('#instrument-explorer');
  const hotspotList = $('#explorer-hotspots');
  if (!canvas || !hotspotList) return null;
  const scene = await initInstrumentExplorer(canvas, 'violino');
  const buttons = $$('[data-explorer]');
  const select = type => {
    scene.setType(type);
    buttons.forEach(button => button.classList.toggle('active', button.dataset.explorer === type));
    hotspotList.innerHTML = explorerData[type].map(([symbol, title, text]) => `<div class="explorer-hotspot"><span>${symbol}</span><div><strong>${title}</strong><small>${text}</small></div></div>`).join('');
  };
  buttons.forEach(button => button.addEventListener('click', () => select(button.dataset.explorer)));
  window.addEventListener('instrument-explorer-select', event => select(event.detail));
  select('violino');
  return scene;
}

export function initPresentation() {
  const dialog = $('#presentation-dialog');
  const openButton = $('#presentation-button');
  const closeButton = $('#presentation-close');
  const slide = $('#presentation-slide');
  const counter = $('#presentation-counter');
  const previous = $('#presentation-prev');
  const next = $('#presentation-next');
  if (!dialog || !slide) return;

  const slides = [
    { title: 'Contexto e pergunta-guia', body: '<p>Saída pedagógica à Sala São Paulo e investigação sobre como instrumentos produzem som.</p><p><b>Pergunta:</b> onde a Matemática participa da construção, da afinação e da acústica?</p>' },
    { title: 'Aplicações observadas na Sala São Paulo', body: '<ul><li>Teto com 15 painéis móveis.</li><li>A altura do teto altera o volume acústico do modelo.</li><li>O teto móvel ajuda a adaptar a resposta da sala a repertórios e formações diferentes.</li></ul>' },
    { title: 'Como as famílias produzem som', body: '<ul><li>Cordas: cordas tensionadas.</li><li>Madeiras: colunas de ar.</li><li>Metais: lábios e tubo.</li><li>Percussão: membranas, barras, placas e cordas percutidas.</li></ul>' },
    { title: 'Matemática na construção', body: '<ul><li>Comprimento, tensão e densidade em cordas.</li><li>2^(1/12) e posição dos trastes.</li><li>Comprimento acústico de tubos e válvulas.</li><li>1/L² em barras e 1/r em membranas.</li></ul>' },
    { title: 'Acústica da sala', body: '<p>A fórmula de Sabine relaciona volume e absorção equivalente: RT60 = 0,161V/A.</p><p>O simulador é didático e não substitui medições profissionais.</p>' },
    { title: 'Produto desenvolvido', body: '<p>Infográfico interativo com pesquisa, fotos, áudio, gráficos, modelos tridimensionais, simuladores e experimento.</p>' },
    { title: 'Conclusão', body: '<p>As razões definem intervalos, as equações ajudam a construir instrumentos, as funções representam ondas e a geometria transforma a sala de concertos.</p>' }
  ];
  let index = 0;
  const render = () => {
    slide.innerHTML = `<span class="slide-number">${String(index + 1).padStart(2, '0')}</span><h2>${slides[index].title}</h2>${slides[index].body}`;
    counter.textContent = `${index + 1} / ${slides.length}`;
    previous.disabled = index === 0;
    next.textContent = index === slides.length - 1 ? 'Encerrar' : 'Próximo';
  };
  openButton?.addEventListener('click', () => {
    index = 0;
    render();
    dialog.showModal();
    dialog.requestFullscreen?.().catch?.(() => {});
  });
  closeButton?.addEventListener('click', () => dialog.close());
  previous?.addEventListener('click', () => { if (index > 0) { index -= 1; render(); } });
  next?.addEventListener('click', () => {
    if (index < slides.length - 1) { index += 1; render(); }
    else dialog.close();
  });
  dialog.addEventListener('keydown', event => {
    if (event.key === 'ArrowRight') next?.click();
    if (event.key === 'ArrowLeft') previous?.click();
  });
}
