import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile, stat } from 'node:fs/promises';
import { resolve } from 'node:path';

const root = resolve(import.meta.dirname, '..');
const read = (relativePath, encoding = 'utf8') => readFile(resolve(root, relativePath), encoding);

test('a abertura obrigatória e o título final existem', async () => {
  const html = await read('index.html');
  assert.match(html, /id="intro-trigger"/);
  assert.match(html, /Instrumentos musicais e Matemática/);
  assert.doesNotMatch(html, /Pular introdução/i);
  assert.doesNotMatch(html, /mao-aberta|mao-fechada|hand-cursor/i);
});

test('grupo e professor estão preenchidos', async () => {
  const html = await read('index.html');
  for (const value of ['Caio França', 'Enzo Mota', 'Gabriel Andozia', 'Julio Menezes', 'Marcio Welker Corrêa']) {
    assert.match(html, new RegExp(value));
  }
});

test('quiz e antiga seção institucional foram removidos da página', async () => {
  const html = await read('index.html');
  assert.doesNotMatch(html, /id="quiz|quiz-section|Miniquiz|Desafio final/i);
  assert.doesNotMatch(html, /Quando a arquitetura também participa da música/i);
});

test('experimento do teto possui somente altura como controle variável', async () => {
  const html = await read('index.html');
  const source = await read('src/sections/acoustics.js');
  assert.match(html, /id="ceiling-grab-strip"/);
  assert.match(html, /Arraste o teto/);
  assert.doesNotMatch(html, /hall-occupancy|controle de ocupação/i);
  assert.match(source, /fixedAbsorption/);
  assert.match(source, /setHeight/);
});

test('linha do tempo usa oito marcadores, destaque e diálogo', async () => {
  const html = await read('index.html');
  const source = await read('src/sections/layout.js');
  const data = await read('src/data/timeline.js');
  assert.match(html, /id="timeline-rail"/);
  assert.match(html, /id="timeline-dialog"/);
  assert.match(source, /mouseenter/);
  assert.match(source, /showModal/);
  assert.equal((data.match(/periodo:/g) || []).length, 8);
});

test('mascote possui canvas próprio e o GLB é válido', async () => {
  const html = await read('index.html');
  const layout = await read('src/sections/layout.js');
  assert.match(html, /id="mascot-canvas"/);
  assert.match(layout, /const canvas = \$\('#mascot-canvas'\)/);
  const scene = await read('src/three/scenes.js');
  assert.match(scene, /OrthographicCamera/);
  const modelPath = resolve(root, 'public/assets/models/man head 3d model.glb');
  const audioPath = resolve(root, 'public/assets/audio/marcio_oi_gente_1.ogg');
  assert.ok((await stat(modelPath)).size > 1_000_000);
  assert.ok((await stat(audioPath)).size > 1_000);
  const bytes = await readFile(modelPath);
  assert.equal(bytes.subarray(0, 4).toString('ascii'), 'glTF');
  assert.equal(bytes.readUInt32LE(4), 2);
  assert.equal(bytes.readUInt32LE(8), bytes.length);
});

test('Three.js está incluído localmente e o inicializador não instala pacotes', async () => {
  const packageJson = JSON.parse(await read('package.json'));
  const html = await read('index.html');
  const launcher = await read('rodar-site.bat');
  const moduleCode = await read('src/vendor/three.module.min.js');
  const coreCode = await read('src/vendor/three.core.min.js');
  assert.equal(packageJson.dependencies, undefined);
  assert.match(html, /\.\/src\/vendor\/three\.module\.min\.js/);
  assert.doesNotMatch(launcher, /npm install/i);
  assert.match(moduleCode, /three\.core\.min\.js/);
  assert.match(coreCode, /REVISION = '185'/);
  assert.ok((await stat(resolve(root, 'src/vendor/three.module.min.js'))).size > 300_000);
  assert.ok((await stat(resolve(root, 'src/vendor/three.core.min.js'))).size > 1_000_000);
});
